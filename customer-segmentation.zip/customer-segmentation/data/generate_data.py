"""Generate the synthetic demonstration dataset (not real customer data)."""
from pathlib import Path

import numpy as np
import pandas as pd

rng = np.random.default_rng(7)

# (age, income k$, spending score) centres for four behavioural groups
GROUPS = [(24, 38, 78), (44, 98, 82), (52, 92, 22), (36, 42, 28)]
N_PER_GROUP = 50

rows = []
for centre in GROUPS:
    rows.append(rng.normal(centre, (5, 9, 9), size=(N_PER_GROUP, 3)))
data = np.vstack(rows)
rng.shuffle(data)

df = pd.DataFrame({
    "CustomerID": np.arange(1, len(data) + 1),
    "Gender": rng.choice(["Female", "Male"], size=len(data)),
    "Age": data[:, 0].clip(18, 75).round().astype(int),
    "Annual Income (k$)": data[:, 1].clip(12, None).round(1),
    "Spending Score (1-100)": data[:, 2].clip(1, 100).round().astype(int),
})
out = Path(__file__).with_name("sample_customers.csv")
df.to_csv(out, index=False)
print(f"Wrote {len(df)} rows to {out}")
