# Dataset note

`sample_customers.csv` is a **synthetic demonstration dataset** (200 generated rows), not real customer data or a survey. Regenerate it with `python data/generate_data.py`.

Replace it with a properly licensed real dataset if your instructor requires genuine observations.
