"""Segmentation pipeline: preprocessing, K-Means, GMM, PCA and Factor Analysis."""
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA, FactorAnalysis
from sklearn.impute import SimpleImputer
from sklearn.metrics import silhouette_score
from sklearn.mixture import GaussianMixture
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "sample_customers.csv"
ID_COLUMNS = {"customerid", "customer_id", "id", "name"}
MIN_ROWS = 5


def load_sample_data() -> pd.DataFrame:
    return pd.read_csv(DATA_PATH)


def preprocess(df: pd.DataFrame):
    """Drop ID columns, impute, scale numerics and one-hot encode categoricals."""
    if df.empty:
        raise ValueError("The CSV has no rows.")
    df = df.drop(columns=[c for c in df.columns if c.strip().lower() in ID_COLUMNS])
    if len(df) < MIN_ROWS:
        raise ValueError(f"Please provide at least {MIN_ROWS} customer records.")
    if df.shape[1] == 0:
        raise ValueError("No usable feature columns were found.")

    numeric = df.select_dtypes(include=["number", "bool"]).columns.tolist()
    categorical = [c for c in df.columns if c not in numeric]

    parts = []
    if numeric:
        parts.append(("num", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), numeric))
    if categorical:
        parts.append(("cat", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]), categorical))

    X = ColumnTransformer(parts).fit_transform(df)
    return X, df


def _silhouette(X, labels):
    n_labels = len(set(labels))
    if n_labels < 2 or n_labels >= len(X):
        return None
    return round(float(silhouette_score(X, labels)), 3)


def run_analysis(df: pd.DataFrame, k: int = 4) -> dict:
    X, clean = preprocess(df)
    n = len(clean)
    k = max(2, min(k, n - 1))

    km_labels = KMeans(n_clusters=k, n_init=10, random_state=42).fit_predict(X)
    gmm_labels = GaussianMixture(n_components=k, reg_covar=1e-5, random_state=42).fit_predict(X)

    pca = PCA(n_components=min(2, X.shape[1]), random_state=42)
    xy = pca.fit_transform(X)
    if xy.shape[1] == 1:  # single feature: pad the second axis
        xy = np.column_stack([xy[:, 0], np.zeros(n)])

    factor_count = min(2, X.shape[1], n - 1)
    factors = FactorAnalysis(n_components=factor_count, random_state=42).fit_transform(X)

    shown = clean.copy()
    shown["KMeans Cluster"] = km_labels + 1
    shown["GMM Cluster"] = gmm_labels + 1

    numeric_cols = clean.select_dtypes(include=["number"]).columns.tolist()
    profile_cols = numeric_cols[:3]
    summaries = []
    for c in sorted(set(km_labels)):
        part = shown[shown["KMeans Cluster"] == c + 1]
        row = {"cluster": int(c + 1), "customers": int(len(part))}
        for col in profile_cols:
            row[col] = round(float(part[col].mean()), 2)
        summaries.append(row)

    points = [
        {"x": round(float(x), 4), "y": round(float(y), 4), "cluster": int(c + 1)}
        for (x, y), c in zip(xy, km_labels)
    ]

    return {
        "count": n,
        "features": int(X.shape[1]),
        "k": k,
        "kmeans_silhouette": _silhouette(X, km_labels),
        "gmm_silhouette": _silhouette(X, gmm_labels),
        "pca_variance": float(pca.explained_variance_ratio_.sum()),
        "factor_count": factor_count,
        "factor_scores": factors[:, :factor_count].round(3).tolist()[:5],
        "profile_columns": profile_cols,
        "summaries": summaries,
        "points": points,
        "preview": shown.head(8).to_dict("records"),
        "preview_columns": shown.columns.tolist(),
    }
